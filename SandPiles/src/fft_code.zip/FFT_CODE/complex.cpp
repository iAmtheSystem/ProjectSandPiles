//   complex.cpp - impelementation of class
//   of complex number
//
//   The code is property of LIBROW
//   You can use it on your own
//   When utilizing credit LIBROW site

//   Include header file
#include "complex.h"

//   Imaginary unity constants
const complex complex::i(0., 1.);
const complex complex::j(0., 1.);